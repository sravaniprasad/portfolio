function myFunction(){
	alert("view marksheet");
}