package com.UplodingFile;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadingFileApplicationTest {

// 	@Test
// 	void contextLoads() {
// 	}

}
