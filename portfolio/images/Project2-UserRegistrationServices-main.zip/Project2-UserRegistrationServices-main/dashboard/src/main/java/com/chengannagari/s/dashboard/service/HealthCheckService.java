package com.chengannagari.s.dashboard.service;

import com.chengannagari.s.dashboard.Entity.HealthCheckStatus;

public interface HealthCheckService {

	HealthCheckStatus addData(HealthCheckStatus hs);
}
