import { Component } from '@angular/core';
import { StarRatingComponent } from 'ng-starrating';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'foodOrder';
}
