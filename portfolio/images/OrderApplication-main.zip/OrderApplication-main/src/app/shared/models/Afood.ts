 export class Afoods{
//   constructor(id:number){
//     this.id=id;
//   }
    id!:number;
    name!:string;
    price!:string;
    stars:number=0;
    favourite:boolean=false;
    imageUrl!:string;
 }