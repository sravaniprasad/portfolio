export interface Users {
    firstname:string,
    location:string,
    email:string,
    password:string

}

