# Angular_File_Upload
Dumping Excel sheet into database using Angular4 
